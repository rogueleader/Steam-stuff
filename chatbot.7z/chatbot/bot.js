// A simple bot to automate chat with steam friends

var SteamUser = require('steam-user');
var client =  new SteamUser();
client.logOn({"accountName":"sheriff_hax",
"password":"csis27021"});
client.on("loggedOn", function() {

  console.log("Logged onto Steam as " + client.steamID);
client.setPersona(SteamUser.EPersonaState.Online);
});
client.on("friendMessage", function(steamID, message) {
  console.log("Message from " + steamID + ": " + message);
  if(message=="Hi")
   client.chatMessage(steamID, "Hi!");
   else
      client.chatMessage(steamID, "bkl");

});
